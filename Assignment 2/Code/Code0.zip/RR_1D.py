import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math

train_data = pd.read_csv("../Dataset/Regression/1D/1d_team_20_train.txt", sep = " ", header=None, names=["X","Y"])
dev_data = pd.read_csv("../Dataset/Regression/1D/1d_team_20_dev.txt", sep = " ", header=None, names=['XD','YD'])

M = 10
N = 200
lnLambda = -29

Lambda = math.exp(lnLambda)
idx = np.round(np.linspace(0, train_data.shape[0]-1, N).astype(int))

X = train_data.iloc[:,0].values[idx]
Y = train_data.iloc[:,1].values[idx]
XD = dev_data.iloc[:,0].values[idx]
YD = dev_data.iloc[:,1].values[idx]

A = np.ones((X.size, M+1))
for i in range(0,M+1):
	A[:, i] = X ** i

D = np.ones(M+1) * Lambda

pseudo = np.linalg.inv((A.T @ A) + np.diag(D)) @ A.T
Alpha = (pseudo @ Y)[::-1]

model = np.poly1d(Alpha)

# Training Dataset
# plt.title("Plot for M = " + str(M) + ", N = " + str(N) + " and ln(lambda) = " + str(lnLambda))
# plt.scatter(X,Y,  color = 'blue', alpha = 0.2, label = "Training Data")
# plt.plot(X, model(X), color = 'black', label = "Estimation")
# plt.legend()
# plt.show()

# Test Dataset
plt.title("Plot for M = " + str(M) + ", N = " + str(N) + " and ln(lambda) = " + str(lnLambda))
plt.scatter(XD,YD,  color = 'blue', alpha = 0.2, label = "Data")
plt.plot(XD, model(XD), color = 'black', label = "Estimation")
plt.legend()
plt.show()
