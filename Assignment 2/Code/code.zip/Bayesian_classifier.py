from cProfile import label
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math

np.set_printoptions(precision=6, suppress=True)

def p_i(x, mu, sigma):
    sqrtOf_det_sigma = np.linalg.det(sigma)**(1/2)
    inv_sigma = np.linalg.inv(sigma)
    result = (2 * math.pi * sqrtOf_det_sigma)**(-1) * math.exp((-1/2) * ((x - mu).T @ inv_sigma @ (x - mu)))
    return result

train_data = pd.read_csv("../Dataset/Bayesian Classifier/Data/LinearlySeperable/train.txt", sep = ",", header=None, names=["X","Y","C"])
dev_data = pd.read_csv("../Dataset/Bayesian Classifier/Data/LinearlySeperable/dev.txt", sep = ",", header=None, names=['XD','YD', 'CD'])

N = 1050

# train
idx_train = np.round(np.linspace(0, (train_data.shape[0]) - 1, N)).astype(int)

# dev
idx_dev = np.round(np.linspace(0, dev_data.shape[0] - 1, N)).astype(int)

tData = np.array(train_data.iloc[:].values[idx_train])
w1 = tData[tData[:,2] == 1]
w2 = tData[tData[:,2] == 2]
w3 = tData[tData[:,2] == 3]

dData = dev_data.iloc[:].values[idx_dev]
w1D = dData[dData[:,2] == 1]
w2D = dData[dData[:,2] == 2]
w3D = dData[dData[:,2] == 3]

mu1 = np.mean(w1[:,0:2], axis = 0)
mu2 = np.mean(w2[:,0:2], axis = 0)
mu3 = np.mean(w3[:,0:2], axis = 0)

# case 1
C1 = np.cov(np.stack(tData[:,0:2], axis=1))
C2 = np.cov(np.stack(tData[:,0:2], axis=1))
C3 = np.cov(np.stack(tData[:,0:2], axis=1))

# # case 2
# C1 = np.cov(np.stack(w1[:,0:2], axis=1))
# C2 = np.cov(np.stack(w2[:,0:2], axis=1))
# C3 = np.cov(np.stack(w3[:,0:2], axis=1))

# # case 3
# sigma2 = np.var(tData[:,0:2])
# C1 = sigma2 * np.identity(w1.size)
# C2 = sigma2 * np.identity(w1.size)
# C3 = sigma2 * np.identity(w1.size)

w = np.array([1+np.argmax(np.array([p_i(x,mu1,C), p_i(x,mu2,C), p_i(x,mu3,C)])) for x in dData[:,0:2]])

pdf1 = np.array([p_i(x,mu1,C) for x in w1D[:,0:2]])
pdf2 = np.array([p_i(x,mu2,C) for x in w2D[:,0:2]])
pdf3 = np.array([p_i(x,mu3,C) for x in w3D[:,0:2]])

ax = plt.axes(projection ='3d')
surf1 = ax.plot_trisurf(w1D[:,0], w1D[:,1], pdf1, color = "red", alpha = 0.8, label = 'Class 1')
surf2 = ax.plot_trisurf(w2D[:,0], w2D[:,1], pdf2, color = "blue", alpha = 0.8, label = 'Class 2')
surf3 = ax.plot_trisurf(w3D[:,0], w3D[:,1], pdf3, color = "green", alpha = 0.8, label = 'Class 3')
surf1._edgecolors2d = surf1._edgecolor3d
surf1._facecolors2d = surf1._facecolor3d
surf2._edgecolors2d = surf2._edgecolor3d
surf2._facecolors2d = surf2._facecolor3d
surf3._edgecolors2d = surf3._edgecolor3d
surf3._facecolors2d = surf3._facecolor3d
plt.legend()
plt.show()